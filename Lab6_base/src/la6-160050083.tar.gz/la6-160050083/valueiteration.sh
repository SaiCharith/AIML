#!/bin/bash
python3 value_Iteration.py -mdp $1 